<?php
include 'header.php';
echo"<hr>";
include 'index.php';
echo "<hr> ";
include 'footer.php';

?>