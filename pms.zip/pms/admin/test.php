<?php

mkdir("admin",O_CREAT);

?>
