<html>
<head>
  <title>pmis</title>
  <!-- Include all the required style sheets -->
  <link href="css/student.css" rel="stylesheet" type="text/css">

<script type="text/javascript">

</script>
</head>

<body >
<?php

// Session is started and it is checked whether the user is admin or not
session_start();

if ($_SESSION['is_logged_in'] == 0 || !strcmp ( $_SESSION['type'], 'user' )  )
{
    header("Location:index.php");
    die();
}

$name = $_GET['name'];
$id = $_GET['id'];

// Establish connection to the database projects with 'root' as username and ''(nothing) as password
$con=mysqli_connect("localhost","root","","pmis");

// Defensive technique : To check whether the connection to the database is actually established, before we
// access the contents of the database
if (mysqli_connect_errno($con))
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// Basic sql query to update a field in the database
$result = mysqli_query($con,"UPDATE request SET grant1='1' WHERE name='$name' and id='$id'");
if (mysqli_error($con))
{
   die(mysqli_error($con));
}
else
{
  header("location:admin_source_request.php");
}

// close db connection
mysqli_close($con);
?>

</body>
</html>