<html>
<head>
  <title>delete project</title>
  <!-- Include all the required style sheets -->
  <link href="css/student.css" rel="stylesheet" type="text/css">
<script type="text/javascript">

</script>
</head>

<body >

<?php

// Session is started and it is checked whether the user is admin or not
session_start();

if ($_SESSION['is_logged_in'] == 0 || !strcmp ( $_SESSION['type'], 'user' )  )
{
    header("Location:index.php");
    die();
}

$id = $_GET['id'];

// Establish connection to the database projects with 'root' as username and ''(nothing) as password
$con=mysqli_connect("localhost","root","","pmis");

// Defensive technique : To check whether the connection to the database is actually established, before we
// access the contents of the database
if (mysqli_connect_errno($con))
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// Basic sql query to delete a project from the database based on id
$result = mysqli_query($con,"DELETE FROM project WHERE id='$id' ");
if (mysqli_error($con))
{
   die(mysqli_error($con));
}
else
{
  header("location:admin_projects.php");
}

// Close the DB connection
mysqli_close($con);
?>
</body>
</html>