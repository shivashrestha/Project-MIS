<html>

<head>
	<title>PMIS-Forgot Password</title>
	 <link href="css/new_user.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
$username = $_POST['text1'];
$phone = $_POST['text2'];
//$email = mysql_real_escape_string($email);
$newpass = $_POST['text3'];


$con=mysqli_connect("localhost","root","","pmis");

if (mysqli_connect_errno($con))
{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con,"SELECT * FROM users WHERE usn='$username' AND phone='$phone'");
if (mysqli_error($con))
{
   die(mysqli_error($con));
}

if(mysqli_num_rows($result) == 1)
{


// -----Update pass in DB-----
	echo "<br>";
	$newpass = ($newpass);
	mysqli_query($con,"UPDATE users SET passwd='$newpass' WHERE usn='$username' AND phone='$phone'");
	if (mysqli_error($con))
	{
   		die(mysqli_error($con));
	}
	echo "<br><div id=\"already\">Password updated sucessfully<br></div>";

	echo "<a href=\"index.php\" id=\"login_link\">Login here</a>";
}
else{
echo "<br><div id=\"already\">Incorrect username/phone number </div><br>";

  	echo "<br><a href=\"forgot_pass.html\" id=\"back\">Go back</a>";
 }
 mysqli_close($con);
?>
</body>

</html>