-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2016 at 02:30 AM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pmis`
--

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `name` varchar(255) NOT NULL,
  `id` int(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `guide` varchar(50) NOT NULL,
  `year` year(4) NOT NULL,
  `batch` text NOT NULL,
  `department` varchar(20) NOT NULL,
  `semester` varchar(8) NOT NULL,
  `pl` varchar(20) NOT NULL,
  `domain` varchar(30) NOT NULL,
  `abstract` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `review` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`name`, `id`, `author`, `guide`, `year`, `batch`, `department`, `semester`, `pl`, `domain`, `abstract`, `status`, `review`) VALUES
('Management System for Academic Projects', 7, 'Somashekhar', 'Phalachandra', 2008, '', '', '', '0', 'Web', '', 1, 1),
('', 15, 'sdsads', 'asdas', 2017, '', '', '', '0', 'asdasd', '', 0, 2),
('pmis', 24, 'shiva', 'shhiva', 2015, '', '', '', '0', 'web', 'this is good project to..\r\ni love this project\r\nwelcome ...		', 1, 1),
('attendance management system', 25, '4s group', 'shreeram khaitu', 2015, '', '', '', '0', 'desktop', 'attendance management system is a desktop based application created using c and c++. \r\n			', 1, 1),
('', 28, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 29, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 30, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 31, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 32, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 33, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 34, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 35, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 36, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('', 37, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('xyz', 38, '', '', 0000, '', '', '', '0', '', '\r\n				', 0, 2),
('fsdfsdf', 39, '', '', 0000, '', '', '', '', '', '				', 0, 2),
('asd', 40, '', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('mm', 41, '', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('asd', 42, '', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('Student management system', 43, 'shiva shrestha', 'shiva', 2016, '', '', '', 'php', 'web', 'Web based project management system is designed to manage different tasks of a project by dividing project in small modules and allocated to different teams. For every software company this application is compulsory.', 0, 1),
('photo management system', 46, 'shiva shrestha', 'shiva', 2016, '', '', '', 'vb.net', 'web', 'this is very good project.			', 0, 1),
('sam', 47, 'shiva', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('sam', 48, 'sam,shiva,ram', 'kk', 2016, '', '', '', 'php', 'web based', 'hello this asdaskdkmsdks			', 0, 1),
('asdsd', 50, '', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('asdasd', 51, '', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('sss', 52, '', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('', 53, 'sss', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('  ', 54, '  ', '', 0000, '', '', '', '', '', '\r\n				', 0, 2),
('    ', 55, '  ', 'asdasd', 0000, '', '', '', 'sadsd', 'asdsad', '\r\n		sadsad		', 0, 2),
('    ', 56, 'sdfsd', 'sdfdsd', 0000, '', '', '', 'sdf', 'sdf', '\r\n	sdf			', 0, 2),
('asds', 58, 'dsa', 'sd', 0000, 'sad', 'Computer', 'First', 'dd', 'dsa', '\r\n	sdasd			', 1, 2),
('sam', 59, 'sad', 'sadsa', 0000, 'sad', 'Computer', 'First', 'asdsad', 'asdsad', '\r\n		asdasdsd		', 1, 2),
('sam', 60, 'sad', 'sadsa', 0000, 'sad', 'Computer', 'First', 'asdsad', 'asdsad', '\r\n		asdasdsd		', 1, 2),
('sam', 61, 'sad', 'sadsa', 0000, 'sad', 'Computer', 'First', 'asdsad', 'asdsad', '\r\n		asdasdsd		', 1, 2),
('test1', 62, 'sad', 'sadsa', 0000, 'sad', 'Computer', 'First', 'asdsad', 'asdsad', '\r\n		asdasdsd		', 1, 2),
('ams', 63, 'sas', 'assas', 0000, 'ass', 'Computer', 'First', 'sdss', 'adsd', '\r\n		sadsad		', 1, 2),
('ams', 64, 'sas', 'assas', 0000, 'ass', 'Computer', 'First', 'sdss', 'adsd', '\r\n		sadsad		', 1, 2),
('ams', 65, 'sas', 'assas', 0000, 'ass', 'Computer', 'First', 'sdss', 'adsd', '\r\n		sadsad		', 1, 2),
('shiva', 66, 'sa', 'sadsad', 0000, 'sas', 'Computer', 'First', 'sadsd', 'sad', '\r\n	asdsad			', 1, 2),
('test2a', 67, 'sdsad', 'asdsad', 0000, 'sdsd', 'Computer', 'First', 'asdasd', 'asdasd', 'asdasdasd\r\n				', 1, 2),
('test4', 69, 'sadsad', 'sadasd', 0000, 'asdasd', 'Computer', 'First', 'asdasd', 'asdasd', '\r\nasdasd				', 1, 1),
('test5', 70, 'dasdsa', 'asdsd', 0000, 'asdasd', 'Computer', 'First', 'asdasdsad', 'adsads', 'asdasdsd\r\n				', 1, 1),
('test6', 71, 'asdsd', 'sss', 0000, 'sddd', 'Computer', 'First', 'sdsd', 'sdsd', 'asdsdd\r\n				', 1, 1),
('qdsd', 72, 'asdasdas', 'dasda', 0000, 'asdasdas', 'Computer', 'First', 'dasda', 'sdasd', 'asdasd\r\n				', 0, 1),
('test8a', 73, 'sdasdsa', 'dasdas', 0000, 'asdsd', 'Computer', 'First', 'dasdasad', 'sdasd', 'asdasdsad\r\n				', 1, 1),
('ss', 74, 'asdasdas', 'sds', 0000, 'asdasds', 'Computer', 'First', 'asdsd', 'asdsad', 'asdasdasd\r\n				', 1, 1),
('ss', 75, 'asdasdas', 'sds', 0000, 'asdasds', 'Computer', 'First', 'asdsd', 'asdsad', 'asdasdasd\r\n				', 1, 2),
('test7', 76, 'sadasd', 'asdasd', 0000, 'sadsd', 'Computer', 'First', 'sadsads', 'sdasd', 'asdasdsd\r\n				', 1, 1),
('test8', 77, 'sadasd', 'asdasd', 0000, 'sadsd', 'Computer', 'First', 'sadsads', 'sdasd', 'asdasdsd\r\n				', 1, 1),
('pmis', 78, 'shiva\r\nsanjay', 'shiva', 2016, '2070', 'Computer', 'Fifth', 'php', 'web', 'this is good project			', 1, 1),
('pmis', 79, 'shiva\r\nsanjay', 'shiva', 2016, '2070', 'Computer', 'Fifth', 'php', 'web', 'this is good project			', 1, 1),
('pmis', 80, 'sss', 'sss', 0000, '2070', 'Computer', 'First', 'sadsadsad', 'asdasd', 'asasdsdd\r\n				', 1, 1),
('pmis', 81, 'sss', 'sss', 0000, '2070', 'Computer', 'First', 'sadsadsad', 'asdasd', 'asasdsdd\r\n				', 1, 1),
('pmis', 82, 'sss', 'sss', 0000, '2070', 'Computer', 'First', 'sadsadsad', 'asdasd', 'asasdsdd\r\n				', 1, 1),
('pmis', 83, 'sss', 'sss', 0000, '2070', 'Computer', 'First', 'sadsadsad', 'asdasd', 'asasdsdd\r\n				', 1, 1),
('pmis', 84, 'sss', 'sss', 0000, '2070', 'Computer', 'First', 'sadsadsad', 'asdasd', 'asasdsdd\r\n				', 1, 1),
('pms', 85, 'sss', 'sss', 0000, '2070', 'Computer', 'First', 'sadsadsad', 'asdasd', 'asasdsdd\r\n				', 1, 1),
('Email server', 86, 'shiva shrestha\r\nram shrestha\r\nsam karki', 'Er. A.K ', 2016, '2013', 'Electronics and comm', 'Seventh', 'PHP', 'web', 'Email server is a web based application which makes easier to share the information through the internet. This project is designed to those who exchange the information via the network.\r\n				', 1, 1),
('sss', 87, 'sss', 'ssssssssssssssssssssssssssssssssssssffffffgggggghh', 0000, '12', 'Computer', 'First', '12331', '232', 'asdasdsad\r\n				', 1, 2),
('man', 88, 'saas', 'd', 0000, '11', 'Computer', 'First', '22', '222', 'asdasds\r\n				', 1, 1),
('man', 89, 'saas', 'd', 0000, '11', 'Computer', 'First', '22', '222', 'asdasds\r\n				', 1, 1),
('man', 90, 'saas', 'd', 0000, '11', 'Computer', 'First', '22', '222', 'asdasds\r\n				', 1, 1),
('man', 91, 'saas', 'd', 0000, '11', 'Computer', 'First', '22', '222', 'asdasds\r\n				', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
  `name` varchar(20) NOT NULL,
  `id` int(20) NOT NULL,
  `ta` varchar(200) NOT NULL,
  `grant1` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`name`, `id`, `ta`, `grant1`) VALUES
('shiva shrestha', 7, 'i need it', 1),
('shiv', 25, 'm,m n,mn,m', 1),
('shiva1', 24, 'would you please provide me this project.', 1),
('shiv', 49, 'sadasdsads', 1),
('shiv', 57, '', 1),
('shiv', 62, '', 1),
('shiv', 85, 'sdasdsad', 1),
('shiv', 84, '', 1),
('shiv', 86, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `usn` varchar(20) NOT NULL,
  `passwd` varchar(20) NOT NULL,
  `email` text NOT NULL,
  `usertype` text NOT NULL,
  `DOB` date DEFAULT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `phone` text NOT NULL,
  `name` text NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`usn`, `passwd`, `email`, `usertype`, `DOB`, `gender`, `phone`, `name`, `uid`) VALUES
('shiva shrestha', 'shivashrestha', 'sam@c.com', 'user', '2014-01-01', 1, '99999', 'Shiva Shrestha', 2),
('admin', 'shiva', 'shiva@co.com', 'admin', '2016-07-07', 1, '98183123123', 'shiva shrestha', 3),
('admin', 'shiva', 'shiva@co.com', 'admin', '2016-07-07', 1, '98183123123', 'shiva shrestha', 4),
('ad', 'admin', 'aa@at.com', 'admin', '2016-07-04', 1, '13123123', 'Shiva Shrestha', 5),
('shiva', 'shiva', 'shivashrestha44@gmail.com', 'admin', '2016-07-05', 1, '9818373163', 'Shiva Shrestha', 6),
('shiv', 'shiv', 'shivashrestha44@gmail.com', 'user', '2016-07-04', 1, '9818373163', 'Shiva Shrestha', 7),
('shiva1', 'shiva1', 'asdasdsadsads@gamil.com', 'user', '2016-07-04', 1, '123232', 'Shiva Shrestha', 9),
('shivk', 'shivk', 'shivashrestha44@gmail.com', 'user', '2016-08-15', 1, '55', 'shiva', 18),
('ss', 'ss', 'shivashrestha@gmail.com', 'user', '2016-08-08', 1, '8755', 'Shiva Shrestha', 19),
('d', 'd', 'jkbkkj', 'user', '0000-00-00', 1, '87', 'h', 21);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD UNIQUE KEY `pid` (`id`) COMMENT 'project_id';

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`) COMMENT 'user id';

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
