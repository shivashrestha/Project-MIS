To use this project you must have little knowledge of PHP , Mysql, Html, Javascript and CSS.
You must have all the apache server to run this project.

*Note: This is a project created to understand the basic concept of PHP language along with proper documentation about storing Project information of anything. During this I may have used my PRIVATE information. So if found PLEASE DELETE that INFORMATION quickly. THANK YOU*