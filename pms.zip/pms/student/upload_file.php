<html>
<head>
	<title>PMIS - upload file</title>
	<!-- Include all the required style sheets -->
	<link href="../css/upload.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
	// Session is started and it is checked whether the user has logged in or not
	session_start();
	if ($_SESSION['is_logged_in'] == 0 )
	{
	    header("Location:index.php");
	    die();
	}

	// Get all the data from the form in the previous page
	$name=$_POST['title'];
	$author=$_POST['authors'];
	$guide=$_POST['guide'];
	$year=$_POST['year'];
	$batch=$_POST['batch'];
	$department=$_POST['department'];
	$semester=$_POST['semester'];
	$pl=$_POST['languages'];
	$domain=$_POST['domain'];
	$abstract=$_POST['abstract'];
	$status = isset($_POST['check']) && $_POST['check']  ? "1" : "0";
	if($status==1){
		$target_dir = "../projects/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$FileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if file already exists
if (file_exists($target_file)) {
    echo "file already exists,";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["file"]["size"] >2097152){    //file size less than 2MB.
    echo "your file is too large. Please upload file less tha 2MB.";
    $uploadOk = 0;
}
// Allow certain file formats
if($FileType != "zip" && $FileType != "rar") {
   echo "Sorry, zip  file only alloweded.";
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo " your file was not uploaded.";
    echo "<a href=\"student_upload.php\" id=\"back_home\">Go Back</a>";
    exit();
// if everything is ok, try to upload file
} else {
	if(!empty($_FILES['file']['name']))
	{
		$file = $_FILES['file']['name'];
		$file = $name."_".$batch."."."zip";    //file stored as project name_batch.zip
		if (file_exists( $target_dir.$file)) {
    echo "file already exists, your file was not uploaded";
    echo "<a href=\"student_upload.php\" id=\"back_home\">Go Back</a>";
    exit();
       }
         else{
         	move_uploaded_file($_FILES['file']['tmp_name'],"../projects/".$file);	
         }
	}
     else {
        echo "Sorry, there was an error uploading your file.";
        echo "<a href=\"student_upload.php\" id=\"back_home\">Go Back</a>";
        exit();
    }
}


	}
 	
// Establish connection to the database projects with 'root' as username and ''(nothing) as password 	
$con=mysqli_connect("localhost","root","","pmis");

// Defensive technique : To check whether the connection to the database is actually established, before we
// access the contents of the database
if (mysqli_connect_errno($con))
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

if ($name=="" || $author=="" || $guide=="" || $year=="" || $batch=="" || $department=="" || $semester=="" || $pl=="" || $domain=="" ||$abstract=="") {
  	echo "<div id=\"already\">PLEASE ENTER ALL FIELD</div>";
  	echo "<a href=\"student_upload.php\" id=\"back_home\">Go Back</a></div>";
exit();
}

// Basic sql query to to insert data into project table of the database
$sql="INSERT INTO project (name, author, guide, year,batch,department,semester, pl, domain,abstract, status) VALUES
        ('$name', '$author', '$guide', '$year','$batch','$department','$semester', '$pl', '$domain', '$abstract','$status')";


if (!mysqli_query($con,$sql))
{
        die('Error: ' . mysqli_error($con));
}
else
{
        //echo "<br> Your Project has been submitted for review";
}

// Basic sql query to get the project from the database based on name
$res = mysqli_query($con,"SELECT * FROM project WHERE name='$name'");
$row = mysqli_fetch_array($res);



// COde to move the file from temporary folder to required folder and renaming it.

			echo "<div id=\"already\">Project Successfully Uploaded !</div>";

	echo "<a href=\"student_upload.php\" id=\"back_home\">Go Back</a>"
  
?>

</body>

</html>