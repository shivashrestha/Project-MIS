<html>
<head>
	<title>PMIS - User upload page</title>
	<!-- Include all the required style sheets -->
	<link href="../css/upload.css" rel="stylesheet" type="text/css">
	<!--<link href="css/admin_search.css" rel="stylesheet" type="text/css"-->
	<link href="css/student.css" rel="stylesheet" type="text/css">-->
	
	
<script type="text/javascript">

// javascript function to display/hide some data
function selected(cb){

	if(cb.checked == true)
		document.getElementById("tobe_hidden").style.visibility = "visible";
	else
		document.getElementById("tobe_hidden").style.visibility = "hidden";
}
function upload(){
	var ptitle,pauthor,pguide,pyear,pdomain,pabstract,uproject;
	ptitle=(document.form1.title.value);
	pauthor=(document.form1.authors.value);
	pguide=(document.form1.guide.value);
	pyear=(document.form1.year.value);
	pdomain=(document.form1.domain.value);
	pabstract=(document.form1.abstract.value);
	uproject=(document.form1.file.value);
	pbatch=(document.form1.batch.value);
	pdepartment=(document.form1.department.value);
	psemester=(document.form1.semester.value);
}

</script>


</head>
<body >
	<div id="test">
		<div id="title">KHWOPA PROJECT-MIS</div>
		<table id="menu_table" border="0">
			<tr>
				<td id="c1"><a href="student_projects.php" id="home">Home</a></td>
				<td id="c4"><a href="../logout.php" id="signout">Sign Out</a></td>
				
			</tr>
		</table>	
	</div>

	
		<div id="signup_text">Upload</div>
		<form action="upload_file.php" name="form1" method="post" enctype="multipart/form-data">
		<table id="table" border="0">
			<tr>
					<td id="col1">Project Title<sup id="required">*</td>
					<td id="col2"><input type="text" id="project_title" name="title"></td>
				</tr>
				<tr>
					<td id="col1">Developers<sup id="required">*</td>
					<td id="col2"><textarea rows="1" cols="27" id="authors" name="authors"/></textarea></td>
				</tr>
				<tr>
					<td id="col1">Supervisor<sup id="required">*</td>
					<td id="col2"><input type="text" id="guide" name="guide" /></td>
				</tr>
				<tr>
					<td id="col1">Completion Year<sup id="required">*</td>
					<td id="col2"><input type="text" id="year" name="year"/></td>
				</tr>
				<tr>
					<td id="col1">Batch<sup id="required">*</td>
					<td id="col2"><input type="text" id="batch" name="batch"/></td>
				</tr>
				<tr>
					<td id="col1">Department<sup id="required">*</td>
						<td id="col2">
							<select name="department" id="department">
								<option>Computer</option>
								<option>Electronics and communication</option>
								<option>Civil</option>
								<option>Architecture</option>
							</select>
						</td>
				</tr>
				<tr>
					<td id="col1">Semester<sup id="required">*</td>
					<td id="col2">
							<select name="semester" id="semester">
								<option>First                        </option>
								<option>Second</option>
								<option>Third</option>
								<option>Fourth</option>
								<option>Fifth</option>
								<option>Sixth</option>
								<option>Seventh</option>
								<option>Eight</option>
							</select>
						</td>
				</tr>
				<tr>
					<td id="col1" >Platform used<sup id="required">*</td>
					<td id="col2"><input type="text" id="languages" name="languages" /></td>
				</tr>
				<tr>
					<td id="col1">Domain<sup id="required">*</td>
					<td id="col2"><input type="text" id="domain" name="domain"/></td>
				</tr>
				</tr>
				<tr>
					<td id="col1">Abstract<sup id="required">*</td>
					<td id="col22"><textarea rows="10" cols="30" id="info"  name="abstract" required name="info">

				</textarea></td>
				
				<tr>
					<td id="col1">Completed?</td>
					<td id="col2"><input type="checkbox" id="check" onchange="selected(this)" name="check" value="1"/></td>
				</tr>
				<tr id="tobe_hidden">
					<td id="col1">Upload Project<sup id="required">*</td>
					<td id="col2"><input type="file" id="file" name="file" style="text-align: center"></td>
				</tr>
				<tr>
					<td id="col1"></td>
					<td id="col2"><input type="submit" onClick="upload()" value="Upload" style="font-size:1em; width: 30%; position: relative; left: 20%;" id="upload_button"/></td>
					<td id="col2"><input type="reset" value="Cancel" style="font-size:1em; width: 110%; position: relative; right: 20%;" id="upload_button"/></td>
				</tr>
		</table>
	</form>
		<div id="required_text">* Marked Details Required</div>
	
</body>


</html>