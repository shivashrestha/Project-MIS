<html>
<head>
	<title>PMIS-User search page</title>
	<!-- Include all the required style sheets -->
	<link href="../css/student_search.css" rel="stylesheet" type="text/css">
	 
<script type="text/javascript">

// javascript function for asynchronus call, to fetch data dynamically from database using ajax
function showUser(str)
{
if (str=="")
  {
  	document.getElementById("sl").innerHTML="";
  	
  }
  else
  	{
  //document.getElementById("sl").innerHTML="got it";
	
if (window.XMLHttpRequest)
  {
  	// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  }
else
  {
  	// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
	xmlhttp.onreadystatechange=function()
  	{
  
  		if (xmlhttp.readyState==4 && xmlhttp.status==200)
   		{	
  
    		document.getElementById("sl").innerHTML=xmlhttp.responseText;
    	}
  	}
  	var select=document.getElementById("options");
  	var typ=select.options[select.selectedIndex].value;
  
  	var url = "search_result.php?options="+typ+"&queryString="+str;
  	escape(url);
  
  
	xmlhttp.open("GET",url,true);
	xmlhttp.send();  
  }

}


</script>


</head>
<body >
	<div id="test">
    <div id="title">KHWOPA PROJECT-MIS</div>
    <table id="menu_table" border="0">
      <tr>
        <td id="c1"><a href="student_projects.php" id="home">Home</a></td>
        <td id="c4"><a href="../logout.php" id="signout">Sign Out</a></td>
      </tr>
    </table>  
  </div>

	<div id="container">
		 <div id="links_table_container">
      <table id="links_table" border="0" cellspacing="0.6" cellpadding="5">
        <tr>
          <td id="projects_col"><a href="student_projects.php" id="projects">Projects</a></td>
        <tr>
        <tr>
          <td id="search_col"><a href="student_search.php" id="search">Search</a></td>
        <tr>
        <tr>
          <td id="upload_col"><a href="student_upload.php" id="upload">Upload</a></td>
        <tr>
      </table>
    </div>

		<!-- Text box and dropdown for basic searching -->
		<div id="space_container">
			<div id="searching">
					<!--<form action="search.php" method="post">--> 
					<input type="text" id="search_name" onkeyup="showUser(this.value)" value="" name="search"/>
					<select id="options" name="options">
						<!--<option disabled="disabled" selected="selected">Select</option>-->
						<option value="Name">Name</option>
						<option value="Domain">Domain</option>
						<option value="Year">Year</option>
						<option value="PL">Languages</option>
					</select>
					<!--<input type="button" onclick="search()" value="Search" id="search_button"/>-->
			</div>

<div id="sl"></div>

</div>
		</div>
	</div>
</body>
</html>
