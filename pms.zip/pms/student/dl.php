<?php
	$id = $_GET['id'];
	$con=mysqli_connect("localhost","root","","pmis");

// Defensive technique : To check whether the connection to the database is actually established, before we
// access the contents of the database
if (mysqli_connect_errno($con))
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// Basic sql query to get project from the database based on id
$result = mysqli_query($con,"SELECT * FROM project WHERE id=$id");
$row = mysqli_fetch_array($result);
$name=$row['name'];
$batch=$row['batch'];
	$filename = $name."_".$batch.'.zip';
	// set the headers for file download
	$file = $_POST['file_name'];
	header('Content-type: audio/mpeg3');
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    readfile('../projects/'.$filename);
   // header('Content-type: application/zip');
    //header('Content-Disposition: attachment; filename="source.zip" ');
    //readfile("$filename");
?>