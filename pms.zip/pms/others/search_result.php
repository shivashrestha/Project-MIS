<html>
<head>

  <title>PMIS-Publics users</title>
  <!-- Include all the required style sheets -->  
  <link href="../css/admin_search.css" rel="stylesheet" type="text/css">
  <link href="../css/student.css" rel="stylesheet" type="text/css">
</head>
<?php

// Session is started and it is checked whether the user is admin or not
session_start();

if ( isset($_GET['queryString']))
{
  $string = '';


  $text = $_GET['queryString'];

  if(isset($_GET['options']))
  {
    if ($_GET['options'] == "Name")
    {
      $select = "name";
    }
    else if ($_GET['options'] == "Domain")
    {
      $select = "domain";
    }
    else if ($_GET['options']=="Year")
    {
      $select = "year";
    }
    else
    {
      $select = "pl";
    }

    // Establish connection to the database projects with 'root' as username and ''(nothing) as password
    $con=mysqli_connect("localhost","root","","pmis");

    // Defensive technique : To check whether the connection to the database is actually established, before we
    // access the contents of the database
    if (mysqli_connect_errno($con))
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    // Basic sql query to search projects from the database based on name, domain, etc
    if($select != "year")
    {
      $result = mysqli_query($con,"SELECT * FROM project WHERE $select LIKE '%" .$text . "%'");  
    }
    else {
      $result = mysqli_query($con,"SELECT * FROM project WHERE year='$text'");
    }
    if (mysqli_error($con))
    {
       die(mysqli_error($con));
    }

    if(mysqli_num_rows($result) == 0)
    {
      $string .= "<span id=\"search_res_for\">No Significant Results found for : </span>" ."<span id=\"res\">".$text."</span>";
      $string .=  "<br><br>";
    }
    else
    {
      
      $string .= "<span id=\"search_res_for\">Search Results for : </span>"."<span id=\"res\">".$text."</span>";
      $string .= "<br><br>";

      // display results one by one
      while($row = mysqli_fetch_array($result))
      {
        $name = $row['name'];
        $path = "project_description.php?id=".$row['id']."";
        $string .= "<ul>";
        $string .= "<li><a href=\"$path\" target=\"_blank\" id=\"res_link\"> $name </a></li>";
        $string .= "</ul>";
      }
    }

    // close db connection
    mysqli_close($con);
    echo $string;
    exit;
  }
}
?>
  
