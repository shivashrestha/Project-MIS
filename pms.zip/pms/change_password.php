<html>

<head>
	<title>Forgot Password</title>
</head>

<body>
<?php
$username = $_POST['text1'];
$password = $_POST['text2'];
$password = ($password);
$newpass = $_POST['text3'];

$con=mysqli_connect("localhost","root","","pmis");

if (mysqli_connect_errno($con))
{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con,"SELECT * FROM users WHERE usn='$username' AND passwd='$password'");
if (mysqli_error($result))
{
	echo "<br> incorrect user/password";
   //die(mysqli_error($result));
}
else


// ---------SEND MAIL---------

// -----Update pass in DB-----
	{
	$newpass =($newpass);
	mysqli_query($con,"UPDATE users SET passwd='$newpass' WHERE usn='$username'");
	if (mysqli_error($con))
	{
   		die(mysqli_error($con));
	}
	echo "<br>Password Changed<br>";
// ---------------------------
   }
mysqli_close($con);
?>
</body>

</html>